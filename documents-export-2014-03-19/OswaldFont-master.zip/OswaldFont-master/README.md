Oswald Font
==============

Oswald is a reworking of the classic gothic typeface style historically represented by designs such as 'Franklyn Gothic', 'Alternate Gothic', 'News Gothic' and more. The characters of Oswald have been re-drawn and reformed to better fit the pixel grid of standard digital screens. Oswald is designed to be used freely across the internet by web browsers on desktop computers, laptops and mobile devices.

![](http://behance.vo.llnwd.net/profiles11/1419723/projects/8868197/c907bc6ada6d629f90152121b3a9a93c.png)
![](http://behance.vo.llnwd.net/profiles11/1419723/projects/8868197/a897530c44cf0be65f5e61026531040b.png)
